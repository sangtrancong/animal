<?php $__env->startSection('title', 'Trang chủ'); ?>
<?php $__env->startSection('content'); ?>



    <div style="background-color: rgb(227, 224, 224); padding-bottom: 35px">
        <div class="child-content">
            <h3 style="text-align: center;color: #600c8b !important">DANH MỤC SẢN PHẨM</h3>
            <div class="container">
                <div class="row category-list">
                    <div class="col-6 col-lg-4">
                        <div class=" category-item category-item-blue1">
                            <h5>DANH MỤC 1</h5>
                            <p>mô tả danh mục</p>
                        </div>
                    </div>
                    <div class="col-6 col-lg-4">
                        <div class="category-item category-item-red1">
                            <h5>DANH MỤC 2</h5>
                            <p>mô tả danh mục</p>
                        </div>
                    </div>
                    <div class="col-6 col-lg-4">
                        <div class="category-item category-item-green1">
                            <h5>DANH MỤC 3</h5>
                            <p>mô tả danh mục</p>
                        </div>
                    </div>
                    <div class="col-6 col-lg-4">
                        <div class="category-item category-item-blue2">
                            <h5>DANH MỤC 4 </h5>
                            <p>mô tả danh mục</p>
                        </div>
                    </div>
                    <div class="col-6 col-lg-4">
                        <div class="category-item category-item-red2">
                            <h5>DANH MỤC 5</h5>
                            <p>mô tả danh mục</p>
                        </div>
                    </div>
                    <div class="col-6 col-lg-4">
                        <div class="category-item category-item-green2">
                            <h5>DANH MỤC 6</h5>
                            <p>mô tả danh mục</p>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <div id="mobileProductHomepage" style="background-color: rgb(215, 215, 236)">
        <h3 style="text-align: center;color: #600c8b !important">SẢN PHẨM</h3>
        <div class="mobile-product" draggable="true" id="mobile-product">

            <div class="product-item-mobile product-item1" id="product-item1">
                <div draggable="false" class="image-product-mobile">
                    <?php if(isset($product1[0])): ?>
                        <a href="<?php echo e($product1[0]->url); ?>" target="blank">
                            <img draggable="false" height="200px" width="100%" src="/storage/<?php echo e($product1[0]->image); ?>"
                                alt="">
                        </a>
                    <?php endif; ?>
                </div>
                <div class="content-product-mobile">
                    <?php if(isset($product1[0])): ?>
                        <a href="<?php echo e($product1[0]->url); ?>" target="blank">
                            <?php echo e(Str::limit($product1[0]->name, 60, '...')); ?>

                        </a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="product-item-mobile product-item2">
                <div draggable="false" class="image-product-mobile">
                    <?php if(isset($product1[1])): ?>
                        <a href="<?php echo e($product1[1]->url); ?>" target="blank">
                            <img draggable="false" height="200px" width="100%" src="/storage/<?php echo e($product1[1]->image); ?>"
                                alt="">
                        </a>
                    <?php endif; ?>
                </div>
                <div class="content-product-mobile">
                    <?php if(isset($product1[1])): ?>
                        <a href="<?php echo e($product1[1]->url); ?>" target="blank">
                            <?php echo e(Str::limit($product1[1]->name, 60, '...')); ?>

                        </a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="product-item-mobile product-item3">
                <div draggable="false" class="image-product-mobile">
                    <?php if(isset($product1[2])): ?>
                        <a href="<?php echo e($product1[2]->url); ?>" target="blank">
                            <img draggable="false" height="200px" width="100%" src="/storage/<?php echo e($product1[2]->image); ?>"
                                alt="">
                        </a>
                    <?php endif; ?>
                </div>
                <div class="content-product-mobile">
                    <?php if(isset($product1[2])): ?>
                        <a href="<?php echo e($product1[2]->url); ?>" target="blank">
                            <?php echo e(Str::limit($product1[2]->name, 60, '...')); ?>

                        </a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="product-item-mobile product-item4">
                <div draggable="false" class="image-product-mobile">
                    <?php if(isset($product1[3])): ?>
                        <a href="<?php echo e($product1[3]->url); ?>" target="blank">
                            <img draggable="false" height="200px" width="100%" src="/storage/<?php echo e($product1[3]->image); ?>"
                                alt="">
                        </a>
                    <?php endif; ?>
                </div>
                <div class="content-product-mobile">
                    <?php if(isset($product1[3])): ?>
                        <a href="<?php echo e($product1[3]->url); ?>" target="blank">
                            <?php echo e(Str::limit($product1[3]->name, 60, '...')); ?>

                        </a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="product-item-mobile product-item5" id="product-item5">
                <div draggable="false" class="image-product-mobile">
                    <?php if(isset($product2[0])): ?>
                        <a href="<?php echo e($product2[0]->url); ?>" target="blank">
                            <img draggable="false" height="200px" width="100%" src="/storage/<?php echo e($product2[0]->image); ?>"
                                alt="">
                        </a>
                    <?php endif; ?>
                </div>
                <div class="content-product-mobile">
                    <?php if(isset($product2[0])): ?>
                        <a href="<?php echo e($product2[0]->url); ?>" target="blank">
                            <?php echo e(Str::limit($product2[0]->name, 60, '...')); ?>

                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <div id="desktopProductHomepage" style="background-color: rgb(215, 215, 236)">
        <div class="child-content">
            <h3 style="text-align: center;color: #600c8b !important">SẢN PHẨM</h3>
            <div class="container">
                <div class="row carousel-list-homepage">
                    <div class="col-md-12">

                        <div id="myCarousel" class="carousel slide" data-ride="carousel" data-interval="0">
                            <!-- Carousel indicators -->
                            <ol class="carousel-indicators">
                                <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                                <li data-target="#myCarousel" data-slide-to="1"></li>
                                <li data-target="#myCarousel" data-slide-to="2"></li>
                            </ol>
                            <!-- Wrapper for carousel items -->
                            <div class="carousel-inner">
                                <div class="carousel-item active">
                                    <div class="row">
                                        <?php $__currentLoopData = $product1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-sm-3">
                                                <div class="thumb-wrapper">
                                                    <div class="img-box">
                                                        <a href="<?php echo e($p->url); ?>" target="blank"> <img
                                                                style="max-height: 160px;"
                                                                src="/storage/<?php echo e($p->image); ?>" class="img-fluid"
                                                                alt=""></a>

                                                    </div>
                                                    <div class="thumb-content">
                                                        <a href="<?php echo e($p->url); ?>" target="blank">
                                                            <h6 style="font-size: 12px">
                                                                <?php echo e(Str::limit($p->name, 20, '...')); ?></h6>
                                                        </a>


                                                        <a href="<?php echo e($p->url); ?>" target="blank"
                                                            class="btn btn-primary">Xem chi tiết</a>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                    </div>
                                </div>
                                <div class="carousel-item ">
                                    <div class="row">
                                        <?php $__currentLoopData = $product2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-sm-3">
                                                <div class="thumb-wrapper">
                                                    <div class="img-box">
                                                        <img style="max-height: 160px;"
                                                            src="/storage/<?php echo e($p->image); ?>" class="img-fluid"
                                                            alt="">
                                                    </div>
                                                    <div class="thumb-content">
                                                        <h6 style="font-size: 12px"><?php echo e(Str::limit($p->name, 20, '...')); ?>

                                                        </h6>

                                                        <a href="#" class="btn btn-primary">Xem chi tiết</a>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                    </div>
                                </div>
                                <div class="carousel-item ">
                                    <div class="row">
                                        <?php $__currentLoopData = $product3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-sm-3">
                                                <div class="thumb-wrapper">
                                                    <div class="img-box">
                                                        <img style="max-height: 160px;"
                                                            src="/storage/<?php echo e($p->image); ?>" class="img-fluid"
                                                            alt="">
                                                    </div>
                                                    <div class="thumb-content">
                                                        <h6 style="font-size: 12px"><?php echo e(Str::limit($p->name, 20, '...')); ?>

                                                        </h6>

                                                        <a href="#" class="btn btn-primary">Xem chi tiết</a>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                    </div>
                                </div>


                            </div>
                            <!-- Carousel controls -->
                            <a class="carousel-control-prev" href="#myCarousel" data-slide="prev">
                                <i class="fa fa-angle-left"></i>
                            </a>
                            <a class="carousel-control-next" href="#myCarousel" data-slide="next">
                                <i class="fa fa-angle-right"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div style="background-color: rgb(206, 207 ,209); padding-bottom: 35px">
        <div class="child-content">
            <div class="container">
                <h3 style="text-align: center;padding-bottom: 15px;color: #600c8b !important">BÀI VIẾT</h3>
                <div class="row">
                    <?php $__currentLoopData = $port; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-sm-6">
                            <div class="port-home-image">
                                <a href="/port/<?php echo e($p->slug); ?>">
                                    <img title="<?php echo e($p->title); ?>" width="100%" src="/storage/<?php echo e($p->image); ?>"
                                        alt="">
                            </div>
                            </a>

                            <h6 class="port-home-title">
                                <a href="/port/<?php echo e($p->slug); ?>">
                                    <?php echo e(Str::limit($p->title, 60, '...')); ?>

                                </a>

                            </h6>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </div>
            </div>

        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\phulol\App\Webapp\resources\views/client/home.blade.php ENDPATH**/ ?>