<?php $__env->startSection('title', 'Bài viết'); ?>
<?php $__env->startSection('content'); ?>

    <div class="child-content">
        <div class="container">
            <div class="row">

                <div class="col-sm-8">
                    <h3><?php echo e($port->title); ?></h3>
                    <br>
                    <?php if($port->video_url!=null): ?>
                    <iframe width="100%" height="400px" allowfullscreen
                    src="<?php echo e($port->video_url); ?>">
                    </iframe>
                    <?php endif; ?>
                    <h5><?php echo e($port->short_content); ?></h5>
                    <div class="portContentDetailPage">
                        <?php echo $port->content; ?>

                    </div>


                </div>
                <div class="col-sm-4">
                    <?php $__currentLoopData = $portOther; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="item-article">
                        <span class="image-item">
                            <a href="/port/<?php echo e($p->slug); ?>" target="blank"> <img width="100%"
                                src="/storage/<?php echo e($p->image); ?>" /></a>
                        </span>
                        <span> <a href="/port/<?php echo e($p->slug); ?>" target="blank"><?php echo e($p->title); ?></a></span>
                    </div>
                    <hr />
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

            </div>
        </div>

    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\phulol\App\Webapp\resources\views/client/portDetail.blade.php ENDPATH**/ ?>