<?php $__env->startSection('content'); ?>
    <div style="display: flex; justify-content: space-between">
        <h2>Thêm Bài viết</h2>

    </div>

    <hr>
    <form action="/admin/portRef" enctype="multipart/form-data" method="POST">
        <?php echo csrf_field(); ?>

        <div class="form-group">
            <label for="title">Tiêu đề</label>
            <input type="text" class="form-control" value="<?php echo e(old('title')); ?>" id="title" name="title">
            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group">
            <label for="file">Hình ảnh đại diện</label>
            <input id="imageUpload" onchange="readURL(this)" type="file" class="form-control" id="file" name="file" >
            <div ><img id="category-img-tag" style="max-width: 300px;"></div>
            <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group">
            <label for="url">Đường dẫn liên kết</label>
            <input type="text" class="form-control" value="<?php echo e(old('url')); ?>" id="url" name="url">
            <?php $__errorArgs = ['url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>


        <button type="submit" class="btn btn-primary">Thêm</button>
    </form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    var editor = new FroalaEditor('#textEditor', {
    // Set the file upload URL.
    // imageUploadParam: 'image_param',
    // imageUploadMethod:'POST',
    // hight:200,
    // imageUploadURL: "/admin/uploadImage",
    // imageUploadParams: {
    //     froala:'true',
    //     _token: "<?php echo e(csrf_token()); ?>",
    // },
    // requestHeaders: {
    //   'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>",
    // },

});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\phulol\App\Webapp\resources\views/adminView/portRef/addPort.blade.php ENDPATH**/ ?>