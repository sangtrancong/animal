<?php $__env->startSection('title', 'Giới thiệu'); ?>
<?php $__env->startSection('content'); ?>
    <div class="top-space">

    </div>
    <div class="child-content">
        <div class="container" style="padding:0 30px;text-align: justify">
            <div class="row" style="width: 1000px;">
                <h3>Chính sách</h3>

            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\sangt\Downloads\public_html\public_html\resources\views/client/policy.blade.php ENDPATH**/ ?>