<?php $__env->startSection('title', 'Giới thiệu'); ?>
<?php $__env->startSection('content'); ?>
    <div class="top-space">

    </div>
    <div class="child-content">
        <div class="container" style="padding:0 30px;text-align: justify;">
            <div class="row" >
                <div class="col-sm-12">
                    <img style="margin: auto;width: 50%; display: block" src="/storage/images/contact.png" alt="">
                </div>
                <div class="col-sm-12">
                    <form>
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                      <span class="input-group-text"><span><i class="fa fa-user"></i></span></span>
                                    </div>
                                    <input type="text" disabled class="form-control" value="Nguyễn Tấn Phú">

                                  </div>
                                  <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                      <span class="input-group-text"><span><i class="fa fa-phone"></i></span></span>
                                    </div>
                                    <input type="text" disabled class="form-control" value="0963 262  036">
                                  </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                      <span class="input-group-text"><span><i class="fa fa fa-envelope"></i></span></span>
                                    </div>
                                    <input type="text" disabled class="form-control" value="abc@gmail.com">
                                  </div>
                                  <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                      <span class="input-group-text"><span><i class="fa fa-map-marker"></i></span></span>
                                    </div>
                                    <input type="text" disabled class="form-control" value="781 Âu Cơ, P Tân Thành, Quận Tân Phú, TPHCM">
                                  </div>
                            </div>
                            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3919.232911087327!2d106.63667341453801!3d10.793465261830985!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31752952c4658af1%3A0x75df44114cdf64dc!2zNzgxIMSQLiDDgnUgQ8ahLCBQaMaw4budbmcgMTMsIFTDom4gUGjDuiwgVGjDoG5oIHBo4buRIEjhu5MgQ2jDrSBNaW5oLCBWaeG7h3QgTmFt!5e0!3m2!1svi!2s!4v1660639241761!5m2!1svi!2s" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                        </div>


                      </form>
                </div>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\sangt\Downloads\public_html\public_html\resources\views/client/contact.blade.php ENDPATH**/ ?>