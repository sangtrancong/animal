<?php $__env->startSection('title', 'Trang chủ'); ?>
<?php $__env->startSection('content'); ?>



    


    <div style=" padding-bottom: 35px">
        <div class="child-content">
            <div class="container  flexContent">
                <div  class="col-left-top">
                    <?php if(isset($hotContent[0])): ?>
                    <div class="top-port-new ">
                        <article class="thumb"><a href="/port/<?php echo e($hotContent[0]->slug); ?>"><img width="100%" style="max-width: 400px; float: left; padding-right: 15px" src="/storage/<?php echo e($hotContent[0]->image); ?>" alt=""></a> </article>
                        <h4 class="title-port"><a href="/port/<?php echo e($hotContent[0]->slug); ?>"><?php echo e($hotContent[0]->title); ?></a></h4>
                        <p class="short-content"><a href="/port/<?php echo e($hotContent[0]->slug); ?>"><?php echo e($hotContent[0]->short_content); ?></a></p>
                    </div>
                    <?php endif; ?>

                    <div class="sub-port-new">
                        <div class="row">
                            <?php if(isset($hotContent[1])): ?>
                            <div class="col-sm-6" style="border-right: solid 2px #eae7e7">
                                <h5 class="title-port"><a href="/port/<?php echo e($hotContent[1]->slug); ?>"><?php echo e($hotContent[1]->title); ?></a></h5>
                                <div class="short-content"><a href="/port/<?php echo e($hotContent[1]->slug); ?>"><?php echo e($hotContent[1]->short_content); ?></a></div>
                            </div>
                            <?php endif; ?>
                            <?php if(isset($hotContent[2])): ?>
                            <div class="col-sm-6">
                                <h5 class="title-port"><a href="/port/<?php echo e($hotContent[2]->slug); ?>"><?php echo e($hotContent[2]->title); ?></a></h5>
                                <div class="short-content"><a href="/port/<?php echo e($hotContent[2]->slug); ?>"><?php echo e($hotContent[2]->short_content); ?></a></div>
                            </div>
                            <?php endif; ?>



                        </div>
                    </div>
                </div>
                <div class="col-right-top"></div>
            </div>
            <div class="news container">
                <hr>
                <h3>Sức khỏe</h3>

                <div class="port-new-content">
                    <div class="row">
                        <?php $__currentLoopData = $healthContent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-sm-6  port-new-item">
                            <h5 class="title-port"><a href="/port/<?php echo e($h->slug); ?>"><?php echo e($h->title); ?></a></h5>
                            <article class="thumb"> <a href="/port/<?php echo e($h->slug); ?>"><img width="100%" style="max-width: 200px; min-height: 115px; float: left; padding-right: 15px" src="/storage/<?php echo e($h->image); ?>" alt=""></a></article>
                            <p class="short-content"><a href="/port/<?php echo e($h->slug); ?>"><?php echo e($h->short_content); ?></a></p>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                    <div> <a href="/suc-khoe">Xem thêm</a></div>
                </div>
            </div>
            <div class="news container">
                <hr>
                <h3>Giáo dục</h3>

                <div class="port-new-content">
                    <div class="row">
                        <?php $__currentLoopData = $eduContent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-sm-6  port-new-item">
                            <h5 class="title-port"><a href="/port/<?php echo e($h->slug); ?>"><?php echo e($h->title); ?></a></h5>
                            <article class="thumb"> <a href="/port/<?php echo e($h->slug); ?>"><img width="100%" style="max-width: 200px; min-height: 115px; float: left; padding-right: 15px" src="/storage/<?php echo e($h->image); ?>" alt=""></a></article>
                            <p class="short-content"><a href="/port/<?php echo e($h->slug); ?>"><?php echo e($h->short_content); ?></a></p>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                    <div> <a href="/giao-duc">Xem thêm</a></div>
                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\sangt\Downloads\public_html\public_html\resources\views/client/home.blade.php ENDPATH**/ ?>