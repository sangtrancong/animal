<?php $__env->startSection('content'); ?>
    <div style="display: flex; justify-content: space-between">
        <h2>Thêm Bài viết</h2>

    </div>

    <hr>
    <form action="/admin/port" enctype="multipart/form-data" method="POST">
        <?php echo csrf_field(); ?>

        <div class="form-group">
            <label for="title">Tiêu đề</label>
            <input type="text" class="form-control" value="<?php echo e(old('title')); ?>" id="title" name="title">
            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group">
            <label for="video_url">Link Video</label>
            <input type="text" class="form-control" id="video_url" value="<?php echo e(old('video_url')); ?>" name="video_url">
            <?php $__errorArgs = ['video_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group">
            <label for="category">Danh mục</label>
            <select value="<?php echo e(old('category_id')); ?>" class="form-control" name="category_id">
                <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($c->id); ?>"><?php echo e($c->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group">
            <label for="file">Hình ảnh đại diện</label>
            <input type="file" class="form-control" id="file" name="file">
            <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group">
            <label for="exampleFormControlTextarea1">Nội dung ngắn</label>
            <textarea class="form-control" id="exampleFormControlTextarea1" name="short_content" rows="3"><?php echo e(old('short_content')); ?></textarea>
        </div>
        <textarea id="content" name="content"><?php echo e(old('content')); ?></textarea>

        <button type="submit" class="btn btn-primary">Thêm</button>
    </form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\sangt\Downloads\public_html\resources\views/adminView/port/addPort.blade.php ENDPATH**/ ?>