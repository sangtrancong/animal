<?php $__env->startSection('title', 'Bài viết'); ?>
<?php $__env->startSection('content'); ?>

    <div class="child-content">
        <div class="row">

            <div class="col-sm-8">
                <div class="port-list">
                    <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="/port/<?php echo e($p->slug); ?>" title="<?php echo e($p->title); ?>">
                            <div class="port-item">
                                <div class="port-item-image">
                                    <img height="120px" width="100%" src="/storage/<?php echo e($p->image); ?>" />
                                </div>
                                <div class="port-item-content">
                                    <?php echo e($p->title); ?>

                                </div>
                            </div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div style="float: right; padding-right: 15px">
                    <?php echo e($list->links()); ?>

                </div>

            </div>
            <div class="col-sm-4" id="portPageRef">
                <?php $__currentLoopData = $listPortRef; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ref): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="item-article">
                        <span class="image-item">
                            <a href="<?php echo e($ref->url); ?>" target="blank"><img height="70px" width="100px" src="/storage/<?php echo e($ref->image); ?>" /></a>
                        </span>
                        <a href="<?php echo e($ref->url); ?>" target="blank"> <span><?php echo e($ref->title); ?></span></a>
                    </div>
                    <hr />
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>

        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vosuakwv/domains/nguyentanphu.com/public_html/resources/views/client/port.blade.php ENDPATH**/ ?>