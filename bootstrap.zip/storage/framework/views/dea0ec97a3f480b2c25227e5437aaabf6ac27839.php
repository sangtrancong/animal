<?php $__env->startSection('content'); ?>
<div style="display: flex; justify-content: space-between">
    <h2>Danh mục sản phẩm</h2>
   <a class="btn btn-primary" href="/admin/category/create">Thêm danh mục</a>
</div>

<hr>
<table id="datatable" class="display">
    <thead>
        <tr>
            <th>No</th>
            <th>Tên danh mục</th>
            <th>Mô tả</th>
            <th></th>
        </tr>
    </thead>
    <tbody>
        <?php $i=1?>
        <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <tr>
            <td><?php echo e($i++); ?></td>
            <td><?php echo e($item->name); ?></td>
            <td><?php echo e($item->description); ?></td>
            <td>
                <div class="dropdown">
                    <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                      Tùy chọn
                    </button>
                    <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
                      <button class="dropdown-item" onclick="location.href='/admin/category/<?php echo e($item->id); ?>'" type="button">Chỉnh sửa</button>
                      <button class="dropdown-item" type="button">Xóa</button>
                    </div>
                  </div>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\sangt\Downloads\public_html\resources\views/adminView/category/list.blade.php ENDPATH**/ ?>