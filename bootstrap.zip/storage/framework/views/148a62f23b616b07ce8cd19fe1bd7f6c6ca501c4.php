<?php $__env->startSection('title', 'Sản phẩm'); ?>
<?php $__env->startSection('content'); ?>
    <div class="top-space">

    </div>
    <div class="child-content">
        <div class="container">
            <div class="search-group">
                <form action="/product">
                    <h6 class="text-center" style="color: white">Tìm kiếm sản phẩm</h6>
                    <div class="searchBar">
                        <select name="category" onchange="this.form.submit()"  class="selectFilter">
                            <option  class="custom-option" value="all">Tất cả</option>
                            <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option <?php echo e(request()->category==$c->id?'selected':''); ?> class="custom-option"  value="<?php echo e($c->id); ?>"><?php echo e($c->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <div class="search-content">
                            <input  class="inputSearch" value="<?php echo e(request()->productName); ?>" name="productName" type="text" >
                            <button class="btn-custom-search" type="submit"><i class="fa fa-search"></i></button>
                        </div>
                    </div>
                </form>

            </div>
            <div class="search-group-mobile">
                <form action="/product">
                    <div class="searchBar-mobile">
                        <select style="width: 100%" name="category" onchange="this.form.submit()"  class="selectFilter">
                            <option  class="custom-option" value="all">Tất cả</option>
                            <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option <?php echo e(request()->category==$c->id?'selected':''); ?> class="custom-option"  value="<?php echo e($c->id); ?>"><?php echo e($c->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </form>

            </div>

            <div class="row">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3 product-item">
                        <div class="card" >
                            <a target="blank" href="<?php echo e($p->url); ?>"><img class="card-img-top"  src="/storage/<?php echo e($p->image); ?>" alt="Card image cap"></a>
                            <div class="card-body">
                               <a href="<?php echo e($p->url); ?>"><p style="font-size: 13px" class="card-title"><?php echo e(Str::limit($p->name ,40,$end='...')); ?></p></a>
                                
                                <a href="<?php echo e($p->url); ?>" target="blank" class="btn btn-custom">Xem chi tiết</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
            <?php echo e($products->links()); ?>

        </div>


    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\phulol\App\Webapp\resources\views/client/product.blade.php ENDPATH**/ ?>