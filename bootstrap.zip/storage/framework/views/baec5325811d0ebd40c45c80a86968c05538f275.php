<?php $__env->startSection('content'); ?>
<div class="logout-container">
    <div class="btn-group">
        <button type="button" class="btn btn-secondary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Xin chào <?php echo e(session('adminSession')[0]['username']); ?>

        </button>
        <div class="dropdown-menu dropdown-menu-right">
          <button class="dropdown-item" type="button">Trang cá nhân</button>
          <a href="/logout" class="dropdown-item" type="button">Đăng xuất</a>
        </div>
      </div>
</div>
<div style="display: flex; justify-content: space-between">
    <h2>Danh mục sản phẩm</h2>
   <a class="btn btn-primary" href="/admin/account/create">Thêm tài khoản</a>
</div>

<hr>
<table id="datatable" class="display">
    <thead>
        <tr>
            <th>No</th>
            <th>Username</th>
            <th>Trạng thái</th>
            <th></th>
        </tr>
    </thead>
    <tbody>
        <?php $i=1?>
        <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <tr>
            <td><?php echo e($i++); ?></td>
            <td><?php echo e($item->username); ?></td>
            <td>
                <?php if($item->status==1): ?>
                <span class="badge badge-success">Hiển thị</span>
                <?php else: ?>
                <span class="badge badge-warning">Ẩn</span>
                <?php endif; ?>
            </td>
            <td>
                <div class="dropdown">
                    <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                      Tùy chọn
                    </button>
                    <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
                      <button class="dropdown-item" onclick="location.href='/admin/account/<?php echo e($item->id); ?>'" type="button">Chỉnh sửa</button>
                      <a class="dropdown-item" onclick="return confirm('Bạn chắc chắn muốn reset password?')" href="/admin/account/<?php echo e($item->id); ?>/edit">Đặt lại mật khẩu</a>
                    </div>
                  </div>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vosuakwv/domains/nguyentanphu.com/public_html/resources/views/adminView/account/list.blade.php ENDPATH**/ ?>