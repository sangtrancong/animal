<?php $__env->startSection('content'); ?>
    <div>
        <h2>Chỉnh sửa bài viết</h2>
    </div>

    <hr>
    <form action="/admin/port/<?php echo e($port->id); ?>" enctype="multipart/form-data" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo e(method_field('PUT')); ?>

        <div class="form-group">
            <label for="title">Tiêu đề</label>
            <input hidden value="<?php echo e($port->id); ?>" name="id">
            <input type="text" class="form-control" id="title" name="title" value="<?php echo e($port->title); ?>">
            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group">
            <label for="video_url">Link Video</label>
            <input type="text" class="form-control" value="<?php echo e($port->video_url); ?>" id="video_url" name="video_url">
            <?php $__errorArgs = ['video_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group">
            <label for="file">Hình ảnh đại diện</label>
            <input type="file" class="form-control" id="file" name="file">
            <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="row">
            <div class="col-sm-6">
                <div class="form-group">
                    <label for="category">Danh mục</label>
                   <select class="form-control" name="category_id">
                        <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php echo e($port->category_id==$c->id?"selected":""); ?>  value="<?php echo e($c->id); ?>"><?php echo e($c->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </select>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <label for="category">Trạng thái</label>
                   <select class="form-control" name="status">
                            <option <?php echo e($port->status==true?"selected":""); ?> value="1">Hiển thị</option>
                            <option  <?php echo e($port->status==false?"selected":""); ?> value="0">Ẩn</option>
                   </select>
                </div>
            </div>
        </div>
        <div class="form-group">
            <label for="exampleFormControlTextarea1">Nội dung ngắn</label>
            <textarea class="form-control" id="exampleFormControlTextarea1"  name="short_content" rows="3"><?php echo e($port->short_content); ?></textarea>
        </div>
        <textarea id="textEditor" name="content"><?php echo e($port->content); ?></textarea>

        <button type="submit" class="btn btn-primary">Chỉnh sửa</button>
    </form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    var editor = new FroalaEditor('#textEditor', {
    // Set the file upload URL.
    imageUploadParam: 'image_param',
    imageUploadMethod:'POST',
    hight:200,
    imageUploadURL: "/admin/uploadImage",
    imageUploadParams: {
        froala:'true',
        _token: "<?php echo e(csrf_token()); ?>",
    },
    requestHeaders: {
      'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>",
    },
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\phulol\App\Webapp\resources\views/adminView/port/portForm.blade.php ENDPATH**/ ?>