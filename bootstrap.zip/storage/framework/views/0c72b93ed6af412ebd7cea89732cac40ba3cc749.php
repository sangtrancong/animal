<?php $__env->startSection('content'); ?>
<h2>Sidenav Example</h2>
<p>This sidenav is always shown.</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\phulol\App\Webapp\resources\views/adminView/index.blade.php ENDPATH**/ ?>