<?php $__env->startSection('content'); ?>
    <div>
        <h2>Chỉnh sửa sản phẩm</h2>
    </div>

    <hr>
    <form action="/admin/product/<?php echo e($product->id); ?>" enctype="multipart/form-data" method="POST" >
        <?php echo csrf_field(); ?>
        <?php echo e(method_field('PUT')); ?>

        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <input name="id" value="<?php echo e($product->id); ?>" hidden/>
                    <label for="code">Mã sản phẩm</label>
                    <input type="text" class="form-control" value="<?php echo e($product->code); ?>" id="code" name="code">
                    <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label for="name">Tên sản phẩm</label>
                    <input type="text" class="form-control" value="<?php echo e($product->name); ?>" id="name" name="name" >
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label for="url">Đường dẫn liên kết</label>
                    <input type="text" class="form-control" value="<?php echo e($product->url); ?>" id="url" name="url" >
                    <?php $__errorArgs = ['url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label for="category">Trạng thái</label>
                   <select class="form-control" name="status">
                            <option <?php echo e($product->status==true?"selected":""); ?> value="1">Hiển thị</option>
                            <option  <?php echo e($product->status==false?"selected":""); ?> value="0">Ẩn</option>
                   </select>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label for="category">Danh mục</label>
                   <select class="form-control" name="category_id">
                        <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php echo e($product->category_id==$c->id?"selected":""); ?> value="<?php echo e($c->id); ?>"><?php echo e($c->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </select>
                </div>
                <div class="form-group">
                    <label for="file">Hình ảnh</label>
                    <input id="imageUpload" onchange="readURL(this)" type="file" class="form-control" id="file" name="file" >
                    <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div>
                    <img id="category-img-tag" style="max-width: 300px;" src="/storage/<?php echo e($product->image); ?>"/>
                </div>
            </div>

        </div>


        <button type="submit" class="btn btn-primary">Chỉnh sửa</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vosuakwv/domains/nguyentanphu.com/public_html/resources/views/adminView/product/productForm.blade.php ENDPATH**/ ?>