<?php $__env->startSection('title', 'Trang chủ'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-8">
            <iframe style="max-width: 100%;width: 100%; height: 300px; max-height: 100%;"
                src="https://www.youtube.com/embed/tgbNymZ7vqY">
            </iframe>
        </div>
        <div class="col-sm-4">
            <div class="item-article">
                <span class="image-item">
                    <img width="100%"
                        src="https://upload.wikimedia.org/wikipedia/commons/b/b6/Image_created_with_a_mobile_phone.png" />
                </span>
                <span>Lorem ipsum dolor sit amet consectetur adipisicing elit. Repellat laudantium</span>
            </div>
            <hr />
            <div class="item-article">
                <span class="image-item">
                    <img width="100%"
                        src="https://upload.wikimedia.org/wikipedia/commons/b/b6/Image_created_with_a_mobile_phone.png" />
                </span>
                <span>Lorem ipsum dolor sit amet consectetur adipisicing elit. Repellat laudantium</span>
            </div>
            <hr />
            <div class="item-article">
                <span class="image-item">
                    <img width="100%"
                        src="https://upload.wikimedia.org/wikipedia/commons/b/b6/Image_created_with_a_mobile_phone.png" />
                </span>
                <span>Lorem ipsum dolor sit amet consectetur adipisicing elit. Repellat laudantium
                    <p><i></i></p>
                </span>
            </div>
            <hr />
            <div class="item-article">
                <span class="image-item">
                    <img width="100%"
                        src="https://upload.wikimedia.org/wikipedia/commons/b/b6/Image_created_with_a_mobile_phone.png" />
                </span>
                <span>Lorem ipsum dolor sit amet consectetur adipisicing elit. Repellat laudantium</span>
            </div>
            <hr />

        </div>

    </div>
    <div class="col-sm-12">
        <table>
            <thead>
                <th>id</th>
                <th>title</th>
                <th>content</th>
                <th>category</th>
            </thead>
            <tbody>
                <?php $__currentLoopData = $port; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($p->id); ?></td>
                        <td><?php echo e($p->title); ?></td>
                        <td><?php echo e($p->content); ?></td>
                        <td><?php echo e($p->category->name); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\phulol\App\Webapp\resources\views/port/list.blade.php ENDPATH**/ ?>