<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-4">
            <h2>Bài viết</h2>
        </div>
        <div class="col-lg-2 offset-lg-6">
            <a class="btn btn-primary" href="/admin/port/create">Thêm bài viết</a>
        </div>

    </div>

    <hr>
    <table id="datatable" class="display">
        <thead>
            <tr>
                <th>No</th>
                <th>Hình ảnh đại diện</th>
                <th>Tiêu đề</th>
                <th>Trạng thái</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php $i=1?>
            <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <td><?php echo e($i++); ?></td>
                    <td><a ><img style="max-width: 100px;"
                        src="/storage/<?php echo e($item->image); ?>" /></a></td>
                    <td><?php echo e($item->title); ?></td>
                    <td>
                        <?php if($item->status==1): ?>
                        <span class="badge badge-success">Hiển thị</span>
                        <?php elseif($item->status==0): ?>
                        <span class="badge badge-danger">Ẩn</span>
                        <?php else: ?>
                        <span class="badge badge-warning">Ưu tiên</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <div class="dropdown">
                            <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                              Tùy chọn
                            </button>
                            <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
                              <button class="dropdown-item" onclick="location.href='/admin/port/<?php echo e($item->id); ?>'" type="button">Chỉnh sửa</button>
                              <button class="dropdown-item" onclick="location.href='/admin/port/hightlight/<?php echo e($item->id); ?>'" type="button"><?php if($item->status==1): ?>
                                  Ưu tiên
                                  <?php elseif($item->status==2): ?>
                                  Bỏ ưu tiên
                              <?php endif; ?></button>
                              <a class="dropdown-item" onclick="return confirm('Bạn chắc chắn muốn xóa bài viết này?')" href="/admin/port/<?php echo e($item->id); ?>/edit">Xóa</a>
                            </div>
                          </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </tbody>

    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\phulol\App\Webapp\resources\views/adminView/port/list.blade.php ENDPATH**/ ?>