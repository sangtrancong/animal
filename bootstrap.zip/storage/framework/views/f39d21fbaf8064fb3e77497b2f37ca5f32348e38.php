<?php $__env->startSection('content'); ?>
<div style="display: flex; justify-content: space-between">
    <h2>Chỉnh sửa danh mục</h2>

</div>

<hr>
<form action="/admin/category/<?php echo e($category->id); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo e(method_field('PUT')); ?>

    <div class="form-group">
        <input hidden name="id" value="<?php echo e($category->id); ?>"/>
      <label for="category">Tên danh mục</label>
      <input type="text" class="form-control" id="category" value="<?php echo e($category->name); ?>" name="name" placeholder="Nhập tên danh mục">
      <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="text-danger"><?php echo e($message); ?></div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="form-group">
        <label for="exampleFormControlTextarea1">Mô tả</label>
        <textarea class="form-control" id="exampleFormControlTextarea1" name="description" rows="3"><?php echo e($category->description); ?></textarea>
      </div>

    <button type="submit" class="btn btn-primary">Cập nhật</button>
  </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vosuakwv/domains/nguyentanphu.com/public_html/resources/views/adminView/category/categoryForm.blade.php ENDPATH**/ ?>