<?php $__env->startSection('title', 'Bài viết'); ?>
<?php $__env->startSection('content'); ?>


    <div class="child-content">
        <div class="row">

            <div class="col-sm-12">
                <div class="port-list">
                    <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="/port/<?php echo e($p->slug); ?>" title="<?php echo e($p->title); ?>">
                            <div class="port-item">
                                <div class="port-item-image">
                                    <img height="120px" width="100%" src="/storage/<?php echo e($p->image); ?>" />
                                </div>
                                <div class="port-item-content">
                                    <?php echo e($p->title); ?>

                                </div>
                            </div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div style="float: right; padding-right: 15px">
                    <?php echo e($list->links()); ?>

                </div>

            </div>


        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\sangt\Downloads\public_html\public_html\resources\views/client/blog.blade.php ENDPATH**/ ?>