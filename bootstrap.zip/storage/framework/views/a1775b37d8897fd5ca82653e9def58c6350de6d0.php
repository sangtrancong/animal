<?php $__env->startSection('content'); ?>
    <div>
        <h2>Chỉnh sửa bài viết</h2>
    </div>

    <hr>
    <form action="/admin/portRef/<?php echo e($port->id); ?>" enctype="multipart/form-data" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo e(method_field('PUT')); ?>

        <div class="form-group">
            <label for="title">Tiêu đề</label>
            <input hidden value="<?php echo e($port->id); ?>" name="id">
            <input type="text" class="form-control" id="title" name="title" value="<?php echo e($port->title); ?>">
            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group">
            <label for="title">Đường dẫn liên kết</label>
            <input hidden value="<?php echo e($port->url); ?>" name="id">
            <input type="text" class="form-control" id="title" name="url" value="<?php echo e($port->url); ?>">
            <?php $__errorArgs = ['url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="row">
            <div class="col-sm-6">
                <div class="form-group">
                    <label for="category">Trạng thái</label>
                   <select class="form-control" name="status">
                            <option <?php echo e($port->status==true?"selected":""); ?> value="1">Hiển thị</option>
                            <option  <?php echo e($port->status==false?"selected":""); ?> value="0">Ẩn</option>
                   </select>
                </div>
            </div>
           <div class="col-sm-6">
            <div class="form-group">
                <label for="file">Hình ảnh đại diện</label>
                <input id="imageUpload" onchange="readURL(this)" type="file" class="form-control" id="file" name="file" >
                <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div>
                <img id="category-img-tag" style="max-width: 300px;" src="/storage/<?php echo e($port->image); ?>"/>
            </div>
           </div>

        </div>


        <button type="submit" class="btn btn-primary">Chỉnh sửa</button>
    </form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    var editor = new FroalaEditor('#textEditor', {
    // // Set the file upload URL.
    // imageUploadParam: 'image_param',
    // imageUploadMethod:'POST',
    // hight:200,
    // imageUploadURL: "/admin/uploadImage",
    // imageUploadParams: {
    //     froala:'true',
    //     _token: "<?php echo e(csrf_token()); ?>",
    // },
    // requestHeaders: {
    //   'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>",
    // },

});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\phulol\App\Webapp\resources\views/adminView/portRef/portForm.blade.php ENDPATH**/ ?>