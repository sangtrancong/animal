@extends('layout.admin')

@section('content')
<h2>Sidenav Example</h2>
<p>This sidenav is always shown.</p>
@endsection
