@extends('layout.index')
@section('title', 'Giới thiệu')
@section('content')
    <div class="top-space">

    </div>
    <div class="child-content">
        <div class="container" style="padding:0 30px;text-align: justify">
            <div class="row" style="width: 1000px;">
                <h3>Chính sách</h3>

            </div>
        </div>

    </div>

@endsection
