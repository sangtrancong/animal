@extends('layout.index')
@section('title', 'Giới thiệu')
@section('content')
    <div class="top-space">

    </div>
    <div class="child-content">
        <div class="container" style="padding:0 30px;text-align: justify">
            <div class="row" style="width: 1000px;">
                <h3>CÔNG TY NGUYỄN PHÚ LOL XIN KÍNH CHÀO QUÝ KHÁCH!</h3>
                <p>Công ty  chúng tôi là một trong những doanh nghiệp uy tín có trụ sở đặt tại TPHCM với nhiều năm kinh nghiệm hoạt động trong lĩnh vực công nghệ thông tin. Khởi nghiệp hoạt động từ năm 2009, chính thức thành lập và phát triển với thương hiệu Phương Nam Vina từ năm 2012, công ty chúng tôi chuyên cung cấp dịch vụ về website phần mềm, dịch vụ lưu trữ dữ liệu, quảng cáo trực tuyến, thương mại điện tử. Với đội ngũ kỹ thuật viên giỏi, có trình độ chuyên môn cao, đội ngũ nhân viên tư vấn nhiệt tình, được đào tạo bài bản về chuyên môn, Phương Nam Vina đã từng bước khẳng định được uy tín trên thị trường công nghệ thông tin bằng chất lượng sản phẩm, dịch vụ cung cấp và thái độ phục vụ khách hàng chuyên nghiệp của đội ngũ nhân viên.</p>
            </div>
        </div>

    </div>

@endsection
